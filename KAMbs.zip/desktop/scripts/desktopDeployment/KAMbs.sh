#!/bin/bash
jre/bin/java -XX:MaxRAMPercentage=60 -classpath "lib/*" kambs.desktopmodule.DesktopLauncher
exit 0

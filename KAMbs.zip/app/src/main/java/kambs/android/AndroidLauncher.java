package kambs.android;

import com.jme3.app.AndroidHarness;
import kambs.game.KAMbs;


public class AndroidLauncher extends AndroidHarness {

    public AndroidLauncher() {
        appClass = KAMbs.class.getCanonicalName();
    }
}
